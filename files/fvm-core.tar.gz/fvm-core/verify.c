

#include<stdio.h>
#include<string.h>
#include<unistd.h>

int main(int argc , char ** argv)
{
	if(argc < 3)
	{
		printf("need minimum 2 arguments\n");
		return 0;
	}


	FILE *fpt ;

	fpt = fopen( *(argv + 1) , "r" );

	if (!fpt)
	{
		printf("password file not exists\n");
		return 0 ;
	}

	char bfs = 32 ;
	char buff[bfs] ;

	fgets( buff , bfs , fpt );

	//printf("%s", buff );




	printf("Welcome to Awnto \n");

	for(int z = 0 ; z < 3 ; z++ )
	{
		printf("Enter Password : ");

		char buffen[bfs];

		scanf("%s" , buffen );

		//printf("%d\n" , strcmp(buff,buffen) );

		char match = 0 ;

		int i;
		for( i = 0 ; i < bfs ; i++  )
		{

			if( buff[i] == 10 )
				buff[i] = 0 ;
			if( buff[i] == 0 || buff[i] != buffen[i]  )
				break;
			//printf("%d:%d\n" , buff[i] , buffen[i]  );
		}
		if( buff[i] == buffen[i] )
			match = 1 ;

		printf("match : %d\n",match);

		if( match == 1 )
			execvp( *(argv + 2) , argv + 2);
	}
	return 0 ;

}



