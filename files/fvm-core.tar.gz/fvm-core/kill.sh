#!./ash

kill `cat lock`
rm lock
