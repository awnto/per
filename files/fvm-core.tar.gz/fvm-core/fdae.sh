#!./ash

#./verify pass ./ash
./dae lock ./telnetd -F -p 5023 -l ./vcf.sh
