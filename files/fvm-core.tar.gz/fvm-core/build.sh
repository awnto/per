#!./ash

mkdir fvm
gcc --static -o fvm/dae dae.c
gcc --static -o fvm/verify verify.c

cp pass fvm/pass
cp fdae.sh fvm/fdae.sh
cp vcf.sh fvm/vcf.sh


echo ""
echo ""
echo "build done ..."
echo ""

