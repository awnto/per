#!./ash

./verify pass ./ash
